/* Language Lens: short tips (English + Arabic) on every menu item and caption button.
   Menu rows get an "i" button (tap or click) and the tip opens under the row; caption buttons show it on hover (mouse),
   on press-and-hold (finger) and on keyboard focus. Never hover-only. Every tip has "Don't show this again": it hides that one
   tip for good; "Show tips" and "Bring back hidden tips" are in More options → Tips (popup too).
   Stored on this device: tipsOff (all tips off) and tipsHidden (list of tip ids). */
(function () {
	'use strict';
	var TIPS = {
		transcript: ['The full text, beside the video.', 'النص الكامل بجانب الفيديو.'],
		ctlb: ['Show ◀ ▶ next to the caption. Keys A and D always work.', 'أظهر ◀ ▶ بجانب الترجمة. مفتاحا A وD يعملان دائمًا.'],
		ctlr: ['Show Repeat, Loop, Shadow and Auto-pause. Keys: S and Q.', 'أظهر الإعادة والتكرار والترديد والإيقاف التلقائي. المفتاحان S وQ.'],
		loop: ['Repeats this sentence again and again, with no pause.', 'يكرّر هذه الجملة مرارًا بدون توقف.'],
		shadow: ['Repeats with a silent gap and a timer, so you can say it along.', 'يكرّرها مع فجوة صامتة ومؤقّت لتقولها معه.'],
		en: ['Show the English captions.', 'أظهر الترجمة الإنجليزية.'],
		tr: ['Show the Arabic under each line.', 'أظهر الترجمة العربية تحت كل سطر.'],
		snd: ['Shows how the words really sound in fast speech, spelled out simply.', 'يُظهر كيف تُنطق الكلمات فعلًا في الكلام السريع، مكتوبة ببساطة.'],
		more: ['Pause rules, hover and music.', 'قواعد الإيقاف والتمرير والموسيقى.'],
		blurEn: ['Hide the English until you tap it.', 'أخفِ الإنجليزية حتى تضغط عليها.'],
		blurTr: ['Hide the Arabic until you tap it.', 'أخفِ العربية حتى تضغط عليها.'],
		colors: ['', ''],
		pauseClick: ['Pauses the video while you read a card opened by a click or tap.', 'يوقف الفيديو أثناء قراءة بطاقة فتحتها بالنقر.'],
		hovtr: ['Meanings open when the mouse rests on a word. Off: click a word.', 'تظهر المعاني عند وقوف الماوس على الكلمة. إيقاف: اضغط على الكلمة.'],
		pauseHover: ['Pauses the video while a hover card is open.', 'يوقف الفيديو أثناء ظهور بطاقة التمرير.'],
		quiz: ['Study the words of a video before you watch it.', 'ادرس كلمات الفيديو قبل مشاهدته.'],
		vocals: ['Listen to songs without background music.', 'استمع إلى الأغاني بدون موسيقى الخلفية.'],
		game: ['Fill in the missing words as the song plays.', 'أكمل الكلمات الناقصة أثناء الأغنية.'],
		prev: ['Back one sentence (A)', 'جملة للخلف'],
		repeat: ['Play this sentence once more (S)', 'أعد هذه الجملة مرة'],
		next: ['Next sentence (D)', 'الجملة التالية'],
		ap: ['Pause after every sentence (Q)', 'توقف بعد كل جملة'],
		save: ['Save this sentence to practise later.', 'احفظ هذه الجملة لتتمرّن عليها.'],
		hideAr: ['Fills your YouTube with English videos.', 'يملأ يوتيوب بفيديوهات إنجليزية.']
	};
	var DN = ['Don’t show this again', 'لا تُظهر هذا مرة أخرى'];
	var st = { off: false, hidden: {}, seen: {}, ar: false }, roots = [];
	var LEGEND = [['learning', 'Learn (in Review)', 'تتعلّمها (في المراجعة)', 'word'], ['next', 'New for you', 'جديدة عليك', 'word'], ['hard', 'Hard or rare', 'صعبة أو نادرة', 'word'], ['ex', 'Phrase', 'عبارة', 'give up'], ['known', 'Known: no mark', 'تعرفها: بدون علامة', 'word']];
	var SAMPLE = { learning: 'background:#FDE68A;color:#0F0F10;padding:0 4px;border-radius:3px', next: 'text-decoration:underline solid #56B4E9 2px;text-underline-offset:3px', hard: 'text-decoration:underline dotted #F59E0B 2px;text-underline-offset:3px', ex: 'text-decoration:underline double #E879F9 2px;text-underline-offset:3px', known: '' };

	function load() {
		chrome.storage.local.get(['tipsOff', 'tipsHidden', 'tipsSeen', 'popupLang'], function (o) {
			var ar = o.popupLang === 'ar';
			var langChanged = ar !== st.ar;
			st.ar = ar;
			st.off = !!o.tipsOff;
			st.hidden = {};
			(o.tipsHidden || []).forEach(function (k) { st.hidden[k] = 1; });
			st.seen = o.tipsSeen || {};
			if (langChanged) roots.forEach(rebuild);
			roots.forEach(apply);
		});
	}
	try {
		chrome.storage.onChanged.addListener(function (ch, area) {
			if (area === 'local' && (ch.tipsOff || ch.tipsHidden || ch.popupLang)) load();
		});
	} catch (e) { /* not in an extension page */ }

	function hide(id) {
		st.hidden[id] = 1;
		chrome.storage.local.set({ tipsHidden: Object.keys(st.hidden) });
		roots.forEach(apply);
	}
	function apply(root) {
		root.querySelectorAll('[data-tip]').forEach(function (el) {
			var gone = st.off || st.hidden[el.dataset.tip];
			el.classList.toggle('tiphid', !!gone);
			if (gone) el.classList.remove('tipopen');
		});
		root.querySelectorAll('[data-a=tipreset]').forEach(function (b) { b.hidden = !!st.off || !Object.keys(st.hidden).length; }); // only when tips are on and one is hidden
		root.querySelectorAll('.tipbox').forEach(function (b) { b.classList.toggle('tiphid', !!(st.off || st.hidden[b.dataset.tipFor])); });
	}

	/** The language changed: build every tip again in the new language. */
	function rebuild(root) {
		root.querySelectorAll('.tipbox, .tipbub, .tipi').forEach(function (n) { n.remove(); });
		root.querySelectorAll('[data-tip-done]').forEach(function (e) { e.removeAttribute('data-tip-done'); });
		attach(root);
	}
	/** Colour words: not a paragraph but a legend with the real word styles. */
	function legend() {
		var w = document.createElement('div');
		w.className = 'tiplg';
		LEGEND.forEach(function (r) {
			var row = document.createElement('div');
			var smp = document.createElement('span');
			smp.textContent = r[3];
			smp.setAttribute('style', SAMPLE[r[0]]);
			var lab = document.createElement('span');
			lab.textContent = st.ar ? r[2] : r[1];
			if (st.ar) lab.dir = 'rtl';
			row.appendChild(smp); row.appendChild(lab);
			w.appendChild(row);
		});
		return w;
	}
	function box(id, floating) {
		var t = TIPS[id], d = document.createElement('div');
		d.className = floating ? 'tipbub' : 'tipbox';
		if (st.ar) d.dir = 'rtl';
		var n = document.createElement('button'); n.type = 'button'; n.className = 'tipdn';
		n.textContent = DN[st.ar ? 1 : 0];
		n.addEventListener('click', function (e) { e.stopPropagation(); e.preventDefault(); hide(id); });
		if (id === 'colors') d.appendChild(legend());
		else d.appendChild(document.createTextNode(t[st.ar ? 1 : 0]));
		d.appendChild(n);
		return d;
	}

	/** root: a shadow root or element. Rows with data-tip="id" get a tip; data-tip-float rows (caption buttons) use a bubble. */
	function attach(root) {
		if (!root || roots.indexOf(root) < 0) roots.push(root);
		root.querySelectorAll('[data-tip]').forEach(function (el) {
			var id = el.dataset.tip;
			if (!TIPS[id] || el.dataset.tipDone) return;
			el.dataset.tipDone = '1';
			if (el.hasAttribute('data-tip-float')) {
				var b = box(id, true);
				el.appendChild(b);
				var tm;
				el.addEventListener('touchstart', function () { tm = setTimeout(function () { el.classList.add('tipopen'); }, 500); }, { passive: true });
				['touchend', 'touchmove', 'touchcancel'].forEach(function (ev) { el.addEventListener(ev, function () { clearTimeout(tm); }, { passive: true }); });
				el.addEventListener('contextmenu', function (e) { if (el.classList.contains('tipopen')) e.preventDefault(); });
				document.addEventListener('pointerdown', function (e) { if (!e.composedPath().includes(el)) el.classList.remove('tipopen'); }, true);
				return;
			}
			var i = document.createElement('button');
			i.type = 'button'; i.className = 'tipi'; i.textContent = 'i'; i.setAttribute('aria-label', 'What is this?');
			el.appendChild(i);
			var tb = box(id, false);
			el.insertAdjacentElement('afterend', tb);
			tb.dataset.tipFor = id;
			i.addEventListener('click', function (e) {
				e.stopPropagation(); e.preventDefault();
				tb.classList.toggle('on'); i.classList.toggle('on');
			});
		});
		apply(root);
	}

	/** First-time hint on one button: open its bubble for a few seconds, up to 3 times. */
	function hint(root, id) {
		var el = root.querySelector('[data-tip="' + id + '"]');
		if (!el || st.off || st.hidden[id] || (st.seen[id] || 0) >= 3) return;
		st.seen[id] = (st.seen[id] || 0) + 1;
		chrome.storage.local.set({ tipsSeen: st.seen });
		el.classList.add('tipopen');
		setTimeout(function () { el.classList.remove('tipopen'); }, 6000);
	}

	/** The tips' look, for a shadow root that uses it. */
	var CSS = '.tipi{all:unset;box-sizing:border-box;cursor:pointer;width:28px;height:28px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;flex:none;margin-left:6px;color:#9AA0A6;font:italic 700 14px Georgia,serif}.tipi:hover,.tipi.on{background:rgba(255,255,255,.16);color:#fff}' +
		'.tipbox{display:none;margin:0 0 4px 2px;padding:7px 10px;background:rgba(0,0,0,.35);border-left:3px solid #FDE68A;border-radius:6px;font-size:12px;line-height:1.4;color:#E6E3DF;text-align:left}.tipbox.on{display:block}' +
		'.tipbox .ta,.tipbub .ta{display:block;direction:rtl;color:#FDE68A;font-size:13px;margin-top:2px;text-align:right}' +
		'.tiplg{display:grid;gap:5px;margin:2px 0}.tiplg div{display:flex;align-items:center;gap:10px}.tiplg div>span:first-child{min-width:64px;font-weight:600}' +
		'.redn{color:#F87171;font-size:12px;margin:-2px 0 6px 2px;line-height:1.35}.redn .o-ar{display:none}:host(.ui-ar) .redn .o-en{display:none}:host(.ui-ar) .redn .o-ar{display:block}' +
		'.tipdn{all:unset;cursor:pointer;display:block;min-height:34px;padding:4px 0;color:#7CC4FF;font-size:12px}.tipdn .ta{color:#7CC4FF;font-size:12px;margin:0}.tipdn:hover{text-decoration:underline}' +
		'.tipbub{position:absolute;bottom:calc(100% + 6px);left:50%;transform:translateX(-50%);display:none;width:max-content;max-width:230px;background:#0E1016;border:1px solid #FDE68A;border-radius:8px;padding:6px 10px;font:400 12px/1.4 "IBM Plex Sans","Segoe UI",system-ui,sans-serif;color:#fff;text-align:left;z-index:5;white-space:normal}' +
		'[data-tip-float]:hover>.tipbub,[data-tip-float]:focus-visible>.tipbub,[data-tip-float].tipopen>.tipbub{display:block}[data-tip-float].tiphid>.tipbub{display:none!important}' +
		'button[hidden]{display:none!important}.tipbox.tiphid,.tipi.tiphid,[data-tip].tiphid>.tipi{display:none!important}';

	load();
	window.LensTips = {
		attach: attach, hint: hint, css: CSS, tips: TIPS,
		reset: function () { st.hidden = {}; st.seen = {}; chrome.storage.local.set({ tipsHidden: [], tipsSeen: {} }); roots.forEach(apply); },
		hiddenCount: function () { return Object.keys(st.hidden).length; },
		setOff: function (v) { chrome.storage.local.set({ tipsOff: !!v }); }
	};
})();
