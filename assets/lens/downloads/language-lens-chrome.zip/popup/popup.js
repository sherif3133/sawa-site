/* Language Lens popup: a controller (0.14.0): sign in, on/off switches, this site. Stats and level live in the Sawa App. */
'use strict';
const $ = (s) => document.querySelector(s);
const LEVELS = ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'];
const LEVEL_HINT = ['Beginner', 'Elementary', 'Intermediate', 'Upper intermediate', 'Advanced', 'Proficient'];

function send(type, data) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage(Object.assign({ type }, data || {}), (res) => {
			if (chrome.runtime.lastError || !res) return reject(new Error('error'));
			return res.ok ? resolve(res.data) : reject(new Error(res.error));
		});
	});
}
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const n = (x) => Math.round(x).toLocaleString('en-US');

async function currentTab() {
	const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
	return tab;
}

/** The "Send feedback" box replaces the popup page; Cancel or OK goes back. */
async function openFeedback(signedIn) {
	const tab = await currentTab().catch(() => null);
	const lang = await send('uiLang').catch(() => 'en');
	$('#app').innerHTML = '<div class="pad" id="fbbox"></div>';
	LensFeedback.mount($('#fbbox'), { from: 'popup', page: tab && tab.url, signedIn, lang, send, onClose: render });
}

function signedOut(err) {
	$('#app').innerHTML = `
		<div class="pad">
			<h1>Learn English from everything you watch and read.</h1>
			<p class="muted">Meanings on hover on YouTube and any website, IPA and "sounds like", your known words, grammar and pronunciation focus, and review cards from your own sentences. For Sawa English members.</p>
		</div>
		<div class="sec">
			<button class="btn" id="login">Sign in with Sawa English</button>
				<p class="fbl"><a href="#" id="fb">💬 Send feedback</a></p>
			${err ? `<p class="err">${esc(err)}</p>` : ''}
		</div>`;
	$('#fb').onclick = (e) => { e.preventDefault(); openFeedback(false); };
	$('#login').onclick = async () => {
		$('#login').disabled = true;
		$('#login').textContent = 'Signing in…';
		try {
			const r = await send('login');
			// Phones: sign-in continues in a new tab, and this popup closes.
			if (r && r.pending) $('#login').textContent = 'A sign-in tab opened: finish there';
			else render();
		} catch (e) {
			signedOut(e.message && e.message !== 'error' ? e.message : 'Sign-in did not finish. Try again.');
		}
	};
}

function toggle(id, label, desc, on) {
	return `<div class="row"><div><div class="t">${label}</div>${desc ? `<div class="d">${desc}</div>` : ''}</div><label class="switch"><input type="checkbox" id="${id}" ${on ? 'checked' : ''}><span></span></label></div>`;
}


/* ------------------------------------------------------------ the controller (0.14.0) */
/* The popup holds the general controls: Open my stats, Language Lens on/off here, meanings, Language Focus. The YouTube-only switches
   (Quiz Mode, caption blur, Hide Arabic videos) are in the Language Lens menu on the video; level and word colours are in the Sawa App
   (profile photo → Settings). English first, العربية switch on top. */
const TX = {
	en: {
		hi: 'Hi', stats: 'Open my stats', statsd: 'Your words, cards and level in the Sawa App',
		rule: 'Language Lens here', rOn: 'On', rPage: 'Off on this page only', rSite: 'Always off on this site', rAll: 'Off everywhere',
		rYT: 'YouTube: Quiz Mode, caption blur and Hide Arabic videos are in the Language Lens menu on the video.',
		meanings: 'Meanings', expl: 'Explanations', explh: 'Notes on words, grammar and lyrics', expr: 'Highlight phrases and idioms',
		focus: 'Language Focus', focd: 'Highlights a grammar point or a sound everywhere, so you notice it', none: '— none —',
		moreset: 'More settings', ipa: 'IPA and "sounds like"', lyrics: 'Lyrics for songs', ainotes: 'AI Analysis (slang and name notes)', wcol: 'Colour words on websites',
		hm: 'Show meanings on websites', hmHover: 'When I hover over a word', hmClick: 'When I click a word', hmAlt: 'When I hover and hold Alt', hmSel: 'Only when I select text',
		proof: 'Check my writing on websites', arh: 'Arabic → English on Arabic pages', are: 'English under Arabic posts', skip: 'Skip links, titles and buttons',
		read: 'Count my reading time', readd: 'Minutes only, never the page. Added to your study log',
		setlvl: 'Set my vocabulary level (30 seconds)', lvlh: 'Your level and word colours are in the Sawa App (profile photo → Settings)',
		app: 'Open the Sawa App', fb: 'Send feedback', out: 'Sign out', free: 'Free account'
	},
	ar: {
		hi: 'أهلًا', stats: 'افتح إحصائياتي', statsd: 'كلماتك وبطاقاتك ومستواك في تطبيق سوا',
		rule: 'Language Lens هنا', rOn: 'يعمل', rPage: 'متوقف في هذه الصفحة فقط', rSite: 'متوقف دائمًا في هذا الموقع', rAll: 'متوقف في كل مكان',
		rYT: 'يوتيوب: وضع الاختبار وتمويه الترجمة وإخفاء الفيديوهات العربية في قائمة Language Lens فوق الفيديو.',
		meanings: 'المعاني', expl: 'الشرح', explh: 'ملاحظات عن الكلمات والقواعد والأغاني', expr: 'أبرز العبارات والتعبيرات',
		focus: 'تركيز اللغة', focd: 'يُبرز نقطة قواعد أو صوتًا في كل مكان لتنتبه له', none: '— بدون —',
		moreset: 'المزيد من الإعدادات', ipa: 'النطق الدولي و"تُنطق كـ"', lyrics: 'كلمات الأغاني', ainotes: 'تحليل الذكاء الاصطناعي (ملاحظات العامية والأسماء)', wcol: 'تلوين الكلمات في المواقع',
		hm: 'إظهار المعاني في المواقع', hmHover: 'عند تمرير الماوس على الكلمة', hmClick: 'عند الضغط على الكلمة', hmAlt: 'عند التمرير مع الضغط على Alt', hmSel: 'فقط عند تحديد النص',
		proof: 'صحّح كتابتي في المواقع', arh: 'عربي ← إنجليزي في الصفحات العربية', are: 'إنجليزي تحت المنشورات العربية', skip: 'تخطَّ الروابط والعناوين والأزرار',
		read: 'احسب وقت قراءتي', readd: 'دقائق فقط، بدون الصفحة. تُضاف إلى سجل مذاكرتك',
		setlvl: 'حدّد مستوى مفرداتي (٣٠ ثانية)', lvlh: 'مستواك وألوان الكلمات في تطبيق سوا (صورتك ← الإعدادات)',
		app: 'افتح تطبيق سوا', fb: 'أرسل ملاحظاتك', out: 'تسجيل الخروج', free: 'حساب مجاني'
	}
};
let LANG = 'en';

function sw(id, label, desc, on) {
	return `<div class="row"><div style="min-width:0"><div class="t">${label}</div>${desc ? `<div class="d">${desc}</div>` : ''}</div><label class="switch big"><input type="checkbox" id="${id}" ${on ? 'checked' : ''}><span></span></label></div>`;
}

async function render() {
	let st;
	try {
		st = await send('state');
	} catch (e) {
		$('#app').innerHTML = '<div class="pad err">Something went wrong. Close this and open it again.</div>';
		return;
	}
	if (!st.signedIn) return signedOut();
	LANG = (await chrome.storage.local.get('popupLang')).popupLang === 'ar' ? 'ar' : 'en';
	const t = TX[LANG];
	document.documentElement.lang = LANG;
	document.documentElement.dir = LANG === 'ar' ? 'rtl' : 'ltr';
	const tab = await currentTab();
	let origin = '';
	try {
		const u = new URL(tab.url);
		if (/^https?:$/.test(u.protocol)) origin = u.origin;
	} catch (e) {
		/* chrome:// pages etc. */
	}
	const isYT = origin === 'https://www.youtube.com' || origin === 'https://m.youtube.com';
	const me = st.me || {};
	const paused = (await send('pausedSites').catch(() => [])).includes(origin);
	const o = await chrome.storage.local.get(['lensAll', 'proofOn', 'skipUi', 'arHover', 'arEnglish', 'hoverMode', 'readTime', 'songLyrics', 'aiNotes', 'lensColors', 'colorPages', 'pausedPages']);
	const cmode = o.lensColors === false && o.colorPages === false ? 'off' : 'on';
	const computer = !matchMedia('(hover: none)').matches && !/Android|iPhone|iPad|Mobile/i.test(navigator.userAgent);
	const more = (await chrome.storage.local.get('popupMore')).popupMore === true;
	const groups = {};
	(st.focusList || []).forEach((f) => { (groups[f.group] = groups[f.group] || []).push(f); });
	const hmode = o.hoverMode || 'hover';
	const pageKey = ((tab && tab.url) || '').split('#')[0];
	const rule = o.lensAll === false ? 'all' : paused ? 'site' : (o.pausedPages || []).includes(pageKey) ? 'page' : 'on';
	const free = me.plan && me.plan.tier === 'free';
	const opt = (v, label) => `<option value="${v}" ${rule === v ? 'selected' : ''}>${label}</option>`;

	$('#app').innerHTML = `
		<div class="sec who" style="border-top:0">
			${me.avatar ? `<img src="${esc(me.avatar)}" alt="">` : ''}
			<div style="flex:1;min-width:0"><b>${t.hi} ${esc(me.firstName || me.name || '')}</b>${free ? `<div class="muted" style="font-size:12.5px">${t.free}</div>` : ''}</div>
			<div class="lg"><button data-lg="en" aria-pressed="${LANG === 'en'}">EN</button><button data-lg="ar" aria-pressed="${LANG === 'ar'}">ع</button></div>
		</div>
		<div class="sec"><a class="btn big" id="stats" href="${esc(me.app || 'https://sawaenglish.com/app/')}" target="_blank" rel="noopener">📊 ${t.stats}</a><p class="hint">${t.statsd}</p></div>
		<div class="sec">
			<div class="label">🔎 ${t.rule}</div>
			<select id="rule" class="fsel big">${isYT ? opt('on', t.rOn) : opt('on', t.rOn) + opt('page', t.rPage) + opt('site', t.rSite)}${opt('all', t.rAll)}</select>
			${isYT ? `<p class="hint">${t.rYT}</p>` : origin ? `<p class="hint">${esc(origin.replace(/^https?:\/\//, ''))}</p>` : ''}
			<p class="err" id="err" hidden></p>
		</div>
		<div class="sec">
			<div class="label">${t.meanings}</div>
			<div class="seg2"><button data-g="en" aria-pressed="${st.glossLang !== 'ar'}">English → English</button><button data-g="ar" lang="ar" aria-pressed="${st.glossLang === 'ar'}">العربية</button></div>
			<div class="label" style="margin-top:12px">${t.expl}</div>
			<div class="seg2"><button data-x="en" aria-pressed="${st.explainLang !== 'ar'}">English</button><button data-x="ar" lang="ar" aria-pressed="${st.explainLang === 'ar'}">العربية</button></div>
			<p class="hint">${t.explh}</p>
			<div style="margin-top:12px">${sw('expr', t.expr, '', st.exprOn !== false)}</div>
		</div>
		<div class="sec">
			<div class="label">🎯 ${t.focus}</div>
			<select id="focus" class="fsel big"><option value="">${t.none}</option>${Object.keys(groups).map((g) => `<optgroup label="${g}">${groups[g].map((f) => `<option value="${esc(f.id)}" ${st.focus === f.id ? 'selected' : ''}>${esc(f.name)}</option>`).join('')}</optgroup>`).join('')}</select>
			<p class="hint">${t.focd}</p>
		</div>
		<details class="more" id="more" ${more ? 'open' : ''}><summary>${t.moreset}</summary>
		<div class="sec">${sw('showIPA', t.ipa, '', st.showIPA !== false)}</div>
		<div class="sec"><div class="label">🎵 Music</div>${sw('songlyrics', t.lyrics, '', o.songLyrics !== false)}<div style="margin-top:12px">${sw('ainotes', t.ainotes, '', o.aiNotes !== false)}</div></div>
		<div class="sec">
			<div class="label">Websites</div>
			${computer ? `<div style="margin-bottom:12px"><div class="label">${t.hm}</div><select id="hmode" class="fsel"><option value="hover" ${hmode === 'hover' ? 'selected' : ''}>${t.hmHover}</option><option value="click" ${hmode === 'click' ? 'selected' : ''}>${t.hmClick}</option><option value="alt" ${hmode === 'alt' ? 'selected' : ''}>${t.hmAlt}</option><option value="select" ${hmode === 'select' ? 'selected' : ''}>${t.hmSel}</option></select></div>` : ''}
			${sw('proof', t.proof, '', o.proofOn !== false)}
			<div style="margin-top:12px">${sw('arhover', t.arh, '', o.arHover !== false)}</div>
			<div style="margin-top:12px">${sw('arenglish', t.are, '', o.arEnglish === true)}</div>
			<div style="margin-top:12px">${sw('skipui', t.skip, '', o.skipUi !== false)}</div>
			<div style="margin-top:12px">${sw('wcolors', t.wcol, '', cmode !== 'off')}</div>
			<div style="margin-top:12px">${sw('readtime', t.read, t.readd, o.readTime === true)}</div>
		</div>
		<div class="sec"><a href="#" id="test">${t.setlvl}</a><p class="hint">${t.lvlh}</p></div>
		</details>
		<div class="sec links">
			<a href="${esc(me.app || 'https://sawaenglish.com/app/')}" target="_blank" rel="noopener">${t.app}</a>
			<a href="#" id="fb">💬 ${t.fb}</a>
			<button id="logout" class="out">${t.out}</button>
		</div>`;

	document.querySelectorAll('[data-lg]').forEach((b) => { b.onclick = async () => { await chrome.storage.local.set({ popupLang: b.dataset.lg }); render(); }; });
	document.querySelectorAll('.seg2 button[data-g]').forEach((b) => { b.onclick = async () => { await send('setPref', { key: 'glossLang', value: b.dataset.g }); render(); }; });
	document.querySelectorAll('.seg2 button[data-x]').forEach((b) => { b.onclick = async () => { await send('setPref', { key: 'explainLang', value: b.dataset.x }); render(); }; });
	const ruleEl = $('#rule');
	ruleEl.onchange = async () => {
		const v = ruleEl.value;
		try {
			const list = ((await chrome.storage.local.get('pausedPages')).pausedPages || []).filter((k) => k !== pageKey);
			if (v === 'page') list.push(pageKey);
			await chrome.storage.local.set({ pausedPages: list.slice(-200), lensAll: v !== 'all', lensYT: v !== 'all' });
			if (origin && !isYT) await send('pauseSite', { origin, paused: v === 'site' });
			if (tab && (v !== 'on' || rule !== 'on')) chrome.tabs.reload(tab.id);
			render();
		} catch (e) {
			const er = $('#err');
			er.hidden = false;
			er.textContent = 'Could not change this page. Refresh it and try again.';
		}
	};
	const store = (id, key) => { const el = $('#' + id); if (el) el.onchange = () => chrome.storage.local.set({ [key]: el.checked }); };
	store('readtime', 'readTime');
	store('proof', 'proofOn');
	store('songlyrics', 'songLyrics');
	store('ainotes', 'aiNotes');
	store('arhover', 'arHover');
	store('arenglish', 'arEnglish');
	store('skipui', 'skipUi');
	const pf = (id, key) => { const el = $('#' + id); if (el) el.onchange = () => send('setPref', { key, value: el.checked }); };
	pf('expr', 'exprOn');
	pf('showIPA', 'showIPA');
	const wc = $('#wcolors'); if (wc) wc.onchange = () => send('setColors', { mode: wc.checked ? 'all' : 'off' });
	const hm = $('#hmode'); if (hm) hm.onchange = (e) => chrome.storage.local.set({ hoverMode: e.target.value });
	$('#focus').onchange = (e) => send('setPref', { key: 'focus', value: e.target.value });
	$('#more').ontoggle = () => chrome.storage.local.set({ popupMore: $('#more').open });
	$('#test').onclick = (e) => { e.preventDefault(); send('openTest').then(() => window.close()); };
	$('#fb').onclick = (e) => { e.preventDefault(); openFeedback(true); };
	$('#logout').onclick = async () => {
		await send('logout');
		render();
	};
	send('sync').catch(() => {});
}

render();
